document.addEventListener("DOMContentLoaded", function() {
    // Category hover interaction
    const category = document.querySelector('.category');
    const categoryList = document.querySelector('.categorylist');

    category.addEventListener('mouseover', () => {
        categoryList.style.display = 'block';
    });

    categoryList.addEventListener('mouseleave', () => {
        categoryList.style.display = 'none';
    });

    // User hover interaction
    const user = document.querySelector('.user');
    const userHover = document.querySelector('.userhover');

    user.addEventListener('mouseover', () => {
        userHover.style.transform = 'scaleY(1)';
    });

    userHover.addEventListener('mouseleave', () => {
        userHover.style.transform = 'scaleY(0)';
    });
});

const mainImage = document.getElementById('mainimg');
const images = document.querySelectorAll('.images .extraimg img');

images.forEach(image => {
    image.addEventListener('click', function () {
        mainImage.src = this.src;
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const buttons = document.querySelectorAll(".topbtns button");
    const contents = document.querySelectorAll(".cartcontent");

    buttons.forEach(button => {
        button.addEventListener("click", function () {
            buttons.forEach(btn => btn.classList.remove("activebtn"));
            button.classList.add("activebtn");
            contents.forEach(content => content.classList.remove("activecontent"));
            document.querySelector(`.cartcontent.${button.name}`).classList.add("activecontent");
        });
    });
});




document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM fully loaded and parsed');
    const image = document.querySelector('.imagemain');
    console.log('Image element:', image);

    if (image) {
        const img = image.querySelector('img');
        console.log('Image inside .imagemain:', img);

        image.addEventListener('mouseenter', function () {
            image.classList.add('zoom');
        });

        image.addEventListener('mouseleave', function () {
            image.classList.remove('zoom');
        });

        image.addEventListener('mousemove', function (e) {
            const rect = image.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            img.style.transformOrigin = `${x}px ${y}px`;
        });
    } else {
        console.error('Element with class "imagemain" not found.');
    }
});

 

document.addEventListener('DOMContentLoaded', (event) => {
    const categoryLinks = document.querySelectorAll('.category');
    const hoverContents = document.querySelectorAll('.hovercontent');

    categoryLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            const hoverClass = link.getAttribute('data-hover');
            const hoverContent = document.querySelector(`.${hoverClass}`);
            hoverContents.forEach(content => content.style.display = 'none');
            if (hoverContent) {
                hoverContent.style.display = 'block';
            }
        });

        link.addEventListener('mouseout', () => {
            const hoverClass = link.getAttribute('data-hover');
            const hoverContent = document.querySelector(`.${hoverClass}`);
            if (hoverContent) {
                hoverContent.style.display = 'none';
            }
        });
    });

    hoverContents.forEach(content => {
        content.addEventListener('mouseover', () => {
            content.style.display = 'block';
        });

        content.addEventListener('mouseout', () => {
            content.style.display = 'none';
        });
    });
});


document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('.leftside ul li');
    const contents = document.querySelectorAll('.right div');

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            tabs.forEach(item => item.classList.remove('activeli'));
            // Add active class to the clicked tab
            this.classList.add('activeli');

            // Hide all content divs
            contents.forEach(content => content.classList.remove('activediv'));


            // Show the corresponding content div
            const target = this.getAttribute('data-target');
            document.getElementById(target).classList.add('activediv');
            document.getElementById("overviewcontentbox").style.display = 'none'
        });
    });
});





// checkbox

// Check the initial state on page load
document.addEventListener('DOMContentLoaded', function () {
const addressSection = document.querySelector(".address-section");
const checkbox = document.getElementById("cbk1-65");

if (checkbox && addressSection) {
    var isChecked = localStorage.getItem("addressSectionHidden") === "true";
    checkbox.checked = isChecked;
    addressSection.style.display = isChecked ? "none" : "block";

    checkbox.addEventListener("change", function () {
        localStorage.setItem("addressSectionHidden", this.checked);
        addressSection.style.display = this.checked ? "none" : "block";
    });
}

// Ensure jQuery is included before this script
jQuery(document).ready(function($) {
    $('.toggle-item').click(function() {
        var $innerList = $(this).next('.innerlist');
        $innerList.slideToggle("slow");
        $(this).find('i').toggleClass('fa-chevron-up fa-chevron-down');
    });
});

jQuery(document).ready(function($) {
    $('#price-range').on('input', function(){
        var rangeVal = $(this).val();
        $('#min-price').val(rangeVal);
        $('#max-price').val(200 - rangeVal);
    });
});


    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 3,
        loop: true,
        spaceBetween: 30,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".button-next",
            prevEl: ".button-prev",
        },
        breakpoints: {
            1025:{
                slidesPerView: 6,
            },
            769:{
                slidesPerView: 5,
            },
            426:{
                slidesPerView: 4,
            },
        }
    });
});

// Navbar js for mobile

const mobilenavbarshow = () =>{
    document.getElementById('slidenavbar').style.left = '0px';
}

const mobilenavbarhidden = () =>{
    document.getElementById('slidenavbar').style.left = '-380px';
}

const showmobileprofilebox = ()=>{
    document.getElementById('slideprofile').style.left = '0px';
}

const mobileprofilehidden = () =>{
    document.getElementById('slideprofile').style.left = '-380px';
}

const slidecategoryshow = () =>{
    document.getElementById('slidecategory').style.left = '0px';
}

const slidecategoryhidden = () =>{
    document.getElementById('slidecategory').style.left = '-380px';
}

const categorylistslideshow = () =>{
    document.getElementById('categorylistslide').style.left = '0px';
}

const categorylistslidehidden = () =>{
    document.getElementById('categorylistslide').style.left = '-380px';
}

const innercatlistshow = () =>{
    document.getElementById('innercatlist').style.left = '0px';
}

const innercatlisthidden = () =>{
    document.getElementById('innercatlist').style.left = '-380px';
}


document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.viewoverview');
    const overviewContent = document.getElementById('overviewcontent');
    const viewDetails = document.getElementById('viewDetails');
    const closeButton = document.getElementById('closeDetails');

    function showViewDetails() {
        overviewContent.style.display = 'none';
        viewDetails.style.display = 'block';
    }

    viewButtons.forEach(button => {
        button.addEventListener('click', showViewDetails);
    });

    closeButton.addEventListener('click', function () {
        overviewContent.style.display = 'block';
        viewDetails.style.display = 'none';
    });

    // Check cookie for flag
    const cookies = document.cookie.split(';');
    const showViewDetailsCookie = cookies.find(cookie => cookie.trim().startsWith('showViewDetails='));

    if (showViewDetailsCookie && showViewDetailsCookie.split('=')[1] === 'true') {
        showViewDetails();
        document.cookie = "showViewDetails=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/"; // Clear the cookie
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const decreaseBtn = document.getElementById('decrease');
    const increaseBtn = document.getElementById('increase');
    const quantityValue = document.getElementById('quantity-value');

    let quantity = parseInt(quantityValue.textContent);

    decreaseBtn.addEventListener('click', function () {
        if (quantity > 1) {
            quantity--;
            quantityValue.textContent = quantity;
        }
    });

    increaseBtn.addEventListener('click', function () {
        quantity++;
        quantityValue.textContent = quantity;
    });
});






let currentStep = 1;

// Function to display the current step
function displayStep(step) {
  // Hide all steps
  document.querySelectorAll('.step').forEach((el) => {
    el.classList.remove('active');
  });

  // Show the current step
  document.querySelector(`.step.step-${step}`).classList.add('active');

  // Update the progress bar
  const progress = (step - 1) * 100 / 2; // Assuming 3 steps
  document.querySelector('.progress-bar').style.width = `${progress}%`;
}

// Function to validate step 1
function validateStep1() {
  let isValid = true;

  // Check if all required fields are filled
  document.querySelectorAll('.step.step-1 .form-control[required]').forEach((field) => {
    if (!field.value.trim()) {
      isValid = false;
      field.classList.add('error');
    } else {
      field.classList.remove('error');
    }
  });

  // If the checkbox is checked, consider it valid
  const checkbox = document.querySelector('.step.step-1 input[type="checkbox"]');
  if (checkbox.checked) {
    return true; // Proceed if checkbox is checked
  }

  // If not checked and required fields are not filled, validation fails
  return isValid;
}

// Initialize the first step
displayStep(currentStep);

// Handle Next and Previous buttons
document.querySelectorAll('.next-step').forEach((button) => {
  button.addEventListener('click', () => {
    if (currentStep === 1) {
      // Validate step 1
      if (validateStep1()) {
        if (currentStep < 3) {
          currentStep++;
          displayStep(currentStep);
        }
      } else {
        // Show error message or indicate that validation failed
        alert('Please fill out all required fields');
      }
    } else {
      if (currentStep < 3) {
        currentStep++;
        displayStep(currentStep);
      }
    }
  });
});


document.querySelectorAll('.prev-step').forEach((button) => {
  button.addEventListener('click', () => {
    if (currentStep > 1) {
      currentStep--;
      displayStep(currentStep);
    }
  });
});

document.addEventListener('DOMContentLoaded', function () {
    const addressCards = document.querySelectorAll('.address-card');
    addressCards.forEach(card => {
        card.addEventListener('click', function () {
            addressCards.forEach(c => c.classList.remove('selected'));
            this.classList.add('selected');
        });
    });
});



